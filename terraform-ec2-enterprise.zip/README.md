# Terraform EC2 Module Setup

## Features
- Remote state with S3 + DynamoDB
- Environment-specific variables using `terraform.tfvars`
- Reusable EC2 module
- Uses `for_each` for better naming and tagging

## Steps to Use
1. Configure AWS CLI and create S3 bucket + DynamoDB table for state.
2. Run `terraform init`.
3. Run `terraform plan`.
4. Run `terraform apply`.

## Fetch Outputs
```bash
terraform output instance_ids
```


## CI/CD with GitHub Actions
This repo includes a GitHub Actions workflow that runs `terraform init`, `plan`, and `apply` automatically on PRs and pushes to main.

### Triggering Workflow
You can pass environment input (dev, stage, prod) to select the correct workspace and tfvars file.

## Multiple Environment Support
- Workspaces: `terraform workspace new dev`
- Apply with environment-specific vars: `terraform apply -var-file=dev.tfvars`


## Remote Backend per Environment
This project now supports separate remote state files for each environment using S3 and DynamoDB.

### Backend Files
- `env-backends/backend-dev.tf`
- `env-backends/backend-stage.tf`
- `env-backends/backend-prod.tf`

### How to Use
1. Copy the appropriate backend file to the root before initializing:
   ```bash
   cp env-backends/backend-dev.tf backend.tf
   terraform init
   ```
2. Repeat for stage or prod environments.

This ensures each environment has its own isolated state file in S3.


## Secure AWS Credentials for GitHub Actions
To allow GitHub Actions to run Terraform commands securely without hardcoding AWS credentials, use **OIDC** or **encrypted secrets**.

### Option 1: OIDC (Recommended)
1. Create an IAM Role in AWS that trusts GitHub's OIDC provider:
   - Go to IAM > Roles > Create Role
   - Select **Web Identity** and choose GitHub OIDC provider
   - Add trust policy for your GitHub repo:
     ```json
     {
       "Version": "2012-10-17",
       "Statement": [
         {
           "Effect": "Allow",
           "Principal": {"Federated": "arn:aws:iam::<ACCOUNT_ID>:oidc-provider/token.actions.githubusercontent.com"},
           "Action": "sts:AssumeRoleWithWebIdentity",
           "Condition": {
             "StringEquals": {
               "token.actions.githubusercontent.com:sub": "repo:<ORG>/<REPO>:ref:refs/heads/main"
             }
           }
         }
       ]
     }
     ```
2. Attach policies like `AmazonEC2FullAccess` or least privilege required.
3. In your GitHub Actions workflow, use:
   ```yaml
   permissions:
     id-token: write
     contents: read

   steps:
     - name: Configure AWS credentials
       uses: aws-actions/configure-aws-credentials@v2
       with:
         role-to-assume: arn:aws:iam::<ACCOUNT_ID>:role/<ROLE_NAME>
         aws-region: us-east-1
   ```

### Option 2: Encrypted Secrets
1. In your GitHub repo, go to **Settings > Secrets and variables > Actions**
2. Add `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY`
3. Update workflow:
   ```yaml
   steps:
     - name: Configure AWS credentials
       uses: aws-actions/configure-aws-credentials@v2
       with:
         aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
         aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
         aws-region: us-east-1
   ```

OIDC is preferred for security and avoids long-lived credentials.


## Terraform Cloud Integration
This project supports Terraform Cloud for remote execution and state management.

### Steps to Configure
1. Create an account at [Terraform Cloud](https://app.terraform.io/).
2. Create an organization and workspace named `ec2-infra`.
3. Authenticate locally:
   ```bash
   terraform login
   ```
4. Replace backend configuration with `backend-terraform-cloud.tf` and run:
   ```bash
   terraform init
   ```

Terraform Cloud provides secure state storage, team collaboration, and policy enforcement.

---

## GitHub Badges
Add these to your README for CI/CD status:

![Terraform CI/CD](https://img.shields.io/github/actions/workflow/status/<ORG>/<REPO>/terraform.yml?branch=main)
![License](https://img.shields.io/github/license/<ORG>/<REPO>)

---

## Architecture Diagram
```
+-------------------+        +-------------------+
|   GitHub Actions  |  --->  | Terraform Cloud   |
+-------------------+        +-------------------+
          |                          |
          v                          v
      AWS EC2 Instances       Remote State Mgmt
```

---

## Enterprise Best Practices
- **Modules**: Keep reusable modules in `modules/` directory.
- **Environments**: Use workspaces and separate tfvars for dev, stage, prod.
- **Security**:
  - Use OIDC for GitHub Actions authentication.
  - Enable encryption for S3 buckets and DynamoDB tables.
  - Apply least privilege IAM policies.
- **CI/CD**:
  - Automate `terraform plan` on PRs and `apply` on main branch.
  - Use GitHub Actions secrets or OIDC for AWS credentials.
- **State Management**:
  - Prefer Terraform Cloud for enterprise setups.
  - Enable state locking and versioning.

---

## Quick Commands
```bash
terraform init
terraform workspace select dev
terraform plan -var-file=dev.tfvars
terraform apply -var-file=dev.tfvars
```
